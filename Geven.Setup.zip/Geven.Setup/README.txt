Geven – Punto de Venta

Geven es una aplicación de punto de venta de escritorio desarrollada como proyecto freelance real, pensada para pequeños y medianos comercios que necesitan una solución simple, clara y funcional para la gestión diaria de ventas y productos.

El objetivo principal del sistema es la sencillez de uso: Geven fue diseñado para que cualquier persona, incluso sin conocimientos técnicos, pueda operar la aplicación sin curva de aprendizaje ni configuraciones complejas.

Funcionalidades principales

La aplicación permite:

Gestión de productos con control de stock

Registro de ventas de forma rápida e intuitiva

Soporte para productos “libres” (ventas sin producto previamente cargado)

Cálculo automático de totales

Visualización de ventas diarias

Importación y exportación de productos mediante archivos Excel

Persistencia local de datos sin necesidad de servidores externos

El sistema prioriza la operación directa y clara, evitando flujos innecesarios o sobrecarga visual.


Enfoque del proyecto

Geven no busca competir con sistemas complejos o sobredimensionados.
El foco está puesto en:

Facilidad de uso

Claridad en la interfaz

Flujo de trabajo simple

Instalación rápida

Funcionamiento completamente local

Esto lo hace ideal para comercios que necesitan una herramienta práctica y confiable para el día a día.


Stack tecnológico

El proyecto fue desarrollado utilizando:

Lenguaje: C#

Framework: .NET (WinForms)

Arquitectura: Capas (BE / BLL / DAL)

Base de datos: SQLite (local)

UI: Windows Forms

Exportación / Importación: Excel (.xlsx)

La elección del stack apunta a estabilidad, simplicidad de despliegue y fácil mantenimiento.


Estado del proyecto

La aplicación se encuentra en una versión funcional y estable, utilizada como base para pruebas reales y mejoras incrementales.
Está pensada para seguir creciendo en base a necesidades concretas del negocio.

Autor: Matías Basterra.

Proyecto desarrollado de forma independiente como solución freelance.